# 📱 TDR Quick Reference Card

**Zamtel TDR Field Monitor**  
*Create your World* 🌍

---

## 🔗 App URL
**https://zamtelsd-max.github.io/Zamtel-TDR-Monitor**

---

## 📥 Install on Your Phone

### Android (Chrome):
1. Open link in **Chrome**
2. Tap **Menu (⋮)** → **"Add to Home Screen"**
3. Tap **"Add"**
4. Done! ✅

### iPhone (Safari):
1. Open link in **Safari** ⚠️ (Not Chrome!)
2. Tap **Share button (□↑)**
3. Tap **"Add to Home Screen"**
4. Tap **"Add"**
5. Done! ✅

---

## 🔐 Login

1. Select **your name** from list
2. Enter your **4-digit PIN**
3. Check "Remember Me" (optional)
4. Tap **"Sign In"**

---

## 📍 Record a Visit

1. Tap **"New Visit"** (+ icon at bottom)
2. Wait for **GPS green checkmark** ✓
3. Fill in ALL fields:
   - **Zone** (select from dropdown)
   - **ZBM Name**
   - **Outlet Name**
   - **Contact** (09X/07X/06X format)
   - **Agent Code**
   - **Town**
   - **Cluster**
   - **Market**
   - **Float Amount** (watch badge color change!)
   - **Notes** (optional)
4. Tap **"Save Visit"**
5. Done! ✅

---

## 🎨 Float Status Colors

| Color | Status | Amount |
|-------|--------|--------|
| 🔴 RED | **CRITICAL** | Less than K500 |
| 🟡 YELLOW | **LOW** | K500 - K1,999 |
| 🟢 GREEN | **OK** | K2,000 or more |

---

## 📊 Your Dashboard

**Shows:**
- 📈 Today's visits count
- 📅 This week's visits
- ⭕ Progress ring (visits vs target)
- 🔴 Critical float count
- 🟡 Low float count
- 📊 Weekly chart
- 🕒 Recent visits

---

## 🏆 Leaderboard

- See top performers
- Gold 🥇 Silver 🥈 Bronze 🥉
- Filter: Today / Week / Month
- Compete with your team!

---

## 📋 My Visits

- Search by outlet or town
- Filter by status (All/Critical/Low/OK)
- Tap any visit to see full details
- Export to Excel/CSV

---

## ⚙️ Settings

**Change:**
- Daily target (default: 10 outlets)
- Google Sheets sync URL
- View installation help

---

## 🔄 Navigation

Bottom menu icons:

| Icon | Screen |
|------|--------|
| 🏠 Home | Dashboard |
| ➕ Plus | New Visit |
| 📋 List | My Visits |
| 🏆 Trophy | Leaderboard |
| ⚙️ Gear | Settings |

---

## ✅ Daily Checklist

**Morning:**
- [ ] Open app
- [ ] Check daily target
- [ ] Review yesterday's visits

**During Day:**
- [ ] Record EVERY outlet visit
- [ ] Check GPS is green before saving
- [ ] Take notes on critical/low float outlets

**Evening:**
- [ ] Review today's count vs target
- [ ] Check leaderboard position
- [ ] Plan tomorrow's visits

---

## 📞 Help & Support

**Email:** zamtel.sd@gmail.com

**Common Issues:**

**GPS not working?**
- Enable Location in phone settings
- Move to open area
- Grant permission to browser

**Can't login?**
- Check your name is spelled correctly
- Try resetting PIN with admin
- Clear browser and try again

**Visit not saving?**
- Check internet connection
- Make sure all fields are filled
- Wait for GPS green checkmark

**App not installing?**
- Android: Use Chrome only
- iPhone: Use Safari only
- Disable pop-up blocker

---

## 🎯 Tips for Success

1. **Always wait for GPS** before saving (green ✓)
2. **Record visits immediately** - don't wait till evening
3. **Check float status** - focus on critical outlets
4. **Aim for target daily** - consistency wins!
5. **Use notes field** - document important info
6. **Export weekly** - review your own data

---

## 🌟 Performance Goals

**Bronze Level:** 5-7 visits/day  
**Silver Level:** 8-9 visits/day  
**Gold Level:** 10+ visits/day  

**Float Management:**
- Identify critical outlets
- Follow up on low float
- Report to ZBM immediately

---

## 📱 App Features at a Glance

✅ Offline capable - works without internet  
✅ Auto-save to Google Sheets  
✅ GPS coordinates for every visit  
✅ Export your data anytime  
✅ Real-time leaderboard  
✅ Color-coded float status  
✅ Weekly performance charts  
✅ Search and filter visits  

---

## 🚀 Quick Actions

**Record visit fast:**
Home → + → Fill form → Save

**Check your rank:**
Home → Trophy icon

**Export data:**
Home → List → Export CSV

**Change target:**
Home → Gear → Daily Target

---

## 📊 What Managers See

Your ZBM and HSD can see:
- All your visits
- Your daily/weekly stats
- Your leaderboard position
- Your float issue resolution rate

**Work hard, aim high!** 🎯

---

## 🆘 Emergency Contacts

**Technical Issues:**  
zamtel.sd@gmail.com

**Your ZBM:**  
[Contact details provided by admin]

**HSD:**  
John Nkhoma (HSD)

---

## 🎓 Training Resources

**Full Manual:** README.md (in app files)  
**Video Tutorial:** [Link provided by admin]  
**WhatsApp Group:** [Invite provided by admin]

---

## 💡 Remember

> "Every visit counts!"  
> "Data is power!"  
> "Create your World!" 🌍

---

**App Version:** 2.0.0  
**Last Updated:** 2024

---

**Keep this card handy!**  
Bookmark this page or screenshot for quick reference.

📱 **Zamtel TDR Field Monitor**  
*Empowering Trade Development Representatives*