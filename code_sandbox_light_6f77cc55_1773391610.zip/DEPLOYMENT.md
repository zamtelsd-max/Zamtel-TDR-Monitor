# 🚀 Quick Deployment Guide

## Upload to GitHub Pages

Your repository: **zamtelsd-max/Zamtel-TDR-Monitor**  
Live URL: **https://zamtelsd-max.github.io/Zamtel-TDR-Monitor**

---

## ✅ Files to Upload

Upload these 8 files to your GitHub repository:

1. ✅ **index.html** (76 KB) - Main application
2. ✅ **manifest.json** - PWA configuration
3. ✅ **service-worker.js** - Offline functionality
4. ✅ **icon-192.png** - App icon (192x192)
5. ✅ **icon-512.png** - App icon (512x512)
6. ✅ **README.md** - Full documentation
7. ✅ **generate-icons.html** (optional) - Icon generator utility
8. ✅ **DEPLOYMENT.md** (this file)

---

## 📤 Upload Steps

### Option 1: GitHub Web Interface (Easiest)

1. Go to: https://github.com/zamtelsd-max/Zamtel-TDR-Monitor
2. Click **"Add file"** → **"Upload files"**
3. Drag and drop ALL files at once
4. Scroll down, add commit message: `v2.0.0 - Updated TDR list and zones`
5. Click **"Commit changes"**
6. Wait 1-2 minutes ⏱️
7. Your app is LIVE at: https://zamtelsd-max.github.io/Zamtel-TDR-Monitor

### Option 2: Replace Existing Files

If files already exist:
1. Click on the file name (e.g., `index.html`)
2. Click the **pencil ✏️ icon** (Edit)
3. Delete all content
4. Copy-paste the NEW content
5. Click **"Commit changes"**
6. Repeat for each file

---

## ⚙️ Enable GitHub Pages (if not already)

1. Go to: https://github.com/zamtelsd-max/Zamtel-TDR-Monitor/settings/pages
2. Under **"Source"**:
   - Branch: **main** ▼
   - Folder: **/ (root)** ▼
3. Click **"Save"**
4. Wait 2 minutes, refresh page
5. You'll see: 
   > ✅ **Your site is live at: https://zamtelsd-max.github.io/Zamtel-TDR-Monitor**

---

## 🧪 Test the App

### On Desktop
1. Open Chrome/Firefox
2. Go to: https://zamtelsd-max.github.io/Zamtel-TDR-Monitor
3. Select a TDR name → Enter PIN → Login
4. Test all screens work

### On Android Phone
1. Open Chrome
2. Go to the app URL
3. Menu (⋮) → "Add to Home Screen"
4. Test GPS, record a visit

### On iPhone
1. Open **Safari** (not Chrome!)
2. Go to the app URL
3. Share button → "Add to Home Screen"
4. Test GPS, record a visit

---

## 🔗 Google Sheets Backend Setup

1. Go to: https://sheets.google.com
2. Sign in with: **zamtel.sd@gmail.com**
3. Create new spreadsheet: **"Zamtel TDR Visits"**
4. Open **Extensions → Apps Script**
5. Paste the backend code (see README.md)
6. **Deploy → New deployment → Web app**
7. Settings:
   - Execute as: **Me**
   - Who has access: **Anyone**
8. Click **Deploy**
9. Copy the **Web App URL**
10. In the app: **Settings → Sync URL → Paste**

---

## 📱 Share with TDRs

### WhatsApp Message Template

```
🚨 NEW ZAMTEL TDR APP 🚨

Hi Team! 📱

We have a NEW app to record outlet visits with GPS tracking!

🔗 INSTALL NOW:
https://zamtelsd-max.github.io/Zamtel-TDR-Monitor

📋 ANDROID (Chrome):
1. Open link in Chrome
2. Menu (⋮) → "Add to Home Screen"
3. Tap "Add"

📋 iPHONE (Safari):
1. Open link in Safari
2. Share button → "Add to Home Screen"
3. Tap "Add"

✅ Your login PIN: [ADMIN SETS THIS]

Questions? Contact: zamtel.sd@gmail.com

Create your World! 🌍
```

### QR Code

Generate a QR code for easy sharing:
1. Go to: https://www.qr-code-generator.com/
2. Enter URL: https://zamtelsd-max.github.io/Zamtel-TDR-Monitor
3. Download QR code image
4. Share in WhatsApp groups / Print on posters

---

## 🎯 Training Checklist

Before rolling out to all TDRs:

- [ ] Test on 3 Android devices
- [ ] Test on 3 iPhones
- [ ] Verify GPS works
- [ ] Test Google Sheets sync
- [ ] Train 2-3 TDRs as champions
- [ ] Create training video (optional)
- [ ] Set daily targets for each TDR
- [ ] Generate PIN codes for all TDRs
- [ ] Share app link via WhatsApp
- [ ] Monitor first week closely

---

## 📊 Monitoring & Reports

### Daily Checks
- Open Google Sheets to see new visits
- Check leaderboard for activity
- Export CSV for analysis
- Respond to any critical float alerts

### Weekly Review
- Export all data to Excel
- Analyze visits by zone
- Review TDR performance
- Identify low-performing outlets
- Plan follow-up visits

---

## 🔄 How to Update the App Later

### To Change TDR Names:
1. Open `index.html` in GitHub
2. Find the `<select id="tdrSelect">` section
3. Add/remove/edit `<option>` tags
4. Commit changes
5. App updates in 1-2 minutes ✅

### To Change Zones:
1. Open `index.html`
2. Find `<select id="visitZone">`
3. Update zone options
4. Commit changes

### To Change Float Thresholds:
1. Open `index.html`
2. Search for `floatAmount < 500` (critical threshold)
3. Search for `floatAmount < 2000` (low threshold)
4. Change values as needed
5. Commit changes

---

## ❓ Common Issues & Fixes

| Problem | Solution |
|---------|----------|
| App shows 404 error | Check GitHub Pages is enabled in Settings |
| Can't install on iPhone | Must use Safari, not Chrome |
| GPS not working | Grant location permission in browser |
| Data not syncing | Check Google Sheets URL is correct |
| Changes not showing | Wait 2 minutes, hard refresh (Ctrl+Shift+R) |
| Login not working | Check TDR name is in dropdown list |

---

## 🎉 You're Ready!

1. ✅ Upload all files to GitHub
2. ✅ Enable GitHub Pages
3. ✅ Test on your phone
4. ✅ Setup Google Sheets backend
5. ✅ Share with TDRs
6. ✅ Monitor and support

**Your app is LIVE**: https://zamtelsd-max.github.io/Zamtel-TDR-Monitor

---

**Questions?** Email: zamtel.sd@gmail.com

**Create your World** 🌍